import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {

	//Declare Variables
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private CardLayout card;
	private CardLayout cardText;
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		//Initialize variables to empty objects
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		textPane = new JPanel();
		textPane.setBackground(Color.BLUE);
		textPane.setBounds(5, 470, 790, 50);
		textPane.setVisible(true);
		buttonPane = new JPanel();
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		//Setup frame attributes
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Destinations SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Setting the layouts for the panels
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
		//logic to add each of the slides and text
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.SOUTH);
	}

	/**
	 * Previous Button Functionality
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}
	
	/**
	 * Next Button Functionality
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**
	 * Method to get the images
	 * Updated image path for detox/wellness vacations
	 * Image citations added to the code comments, to not make any changes to code
	 */
	private String getResizeIcon(int i) {
		String image = ""; 
		if (i==1){
			//Image Source: Davis, S. (2020). Tourist Relaxing in the Hot Springs of Tuscany [Photograph].Https://www.Pexels.com. https://www.pexels.com/photo/tourist-relaxing-in-the-hot-springs-of-tuscany-4340670/
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/healthy food.jpg") + "'</body></html>";
		} else if (i==2){
			//Image Source: Pezeta, L. (2019). Woman Squatting on Ground While Raising Both Hands [Photograph]. Https://www.Pexels.com. https://www.pexels.com/photo/woman-squatting-on-ground-while-raising-both-hands-2035066/
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/hot springs.jpg") + "'</body></html>";
		} else if (i==3){
			//Image Source: None, P. (2017). Grilled Meat Dish Served on White Plate [Photograph]. Https://www.Pexels.com. https://www.pexels.com/photo/grilled-meat-dish-served-on-white-plate-361184/
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/meditation.jpg") + "'</body></html>";
		} else if (i==4){
			//Image Source: Bond, N. (2020). Photo Of Woman Meditating [Photograph]. Https://www.Pexels.com. https://www.pexels.com/photo/photo-of-woman-meditating-3759657/
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/spa.jpg") + "'</body></html>";
		} else if (i==5){
			//Image Source: Tekeridis, J. (2019). Woman Doing Facial Mask [Photograph]. Https://www.Pexels.com. https://www.pexels.com/photo/woman-doing-facial-mask-3212179/
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/yoga.jpg") + "'</body></html>";
		}
		return image;
	}
	
	/**
	 * Method to get the text values
	 */
	private String getTextDescription(int i) {
		String text = ""; 
		if (i==1){
			//Updated slides without changing the appearance of the slide or text
			//Slides appear as vacation rank and title, line break then text description 
			text = "<html><body><font size='5'> #1 Food Detox Retreat </font> <br> Learn how to cook and eat healthy.</body></html>";
		} else if (i==2){
			text = "<html><body>#2 Hot Springs Retreat <br> Relax in the natural hot springs. </body></html>";
		} else if (i==3){
			text = "<html><body>#3 Meditation Retreat <br> Learn how to be mindful. </body></html>";
		} else if (i==4){
			text = "<html><body>#4 Spa Retreat <br> Enjoy massages and facials. </body></html>";
		} else if (i==5){
			text = "<html><body>#5 Yoga Retreat <br> Stretch out instead of stress out. </body></html>";
		}
		return text;
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}